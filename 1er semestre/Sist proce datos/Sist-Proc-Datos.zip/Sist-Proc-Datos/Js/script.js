
function mostrarDatos() {
    var vapellido = document.getElementById("apellido").value;
    var vnombre = document.getElementById("nombre").value;
    var vdni = document.getElementById("dni").value;
    var vfechaNacimiento = document.getElementById("fecha_nacimiento").value;
    var vdomicilio = document.getElementById("domicilio").value;
    var vlocalidad = document.getElementById("localidad").value;

    document.write("Apellido: " + vapellido + "<br>");
    document.write("Nombre: " + vnombre + "<br>");
    document.write("DNI: " + vdni + "<br>");
    document.write("Fecha de Nacimiento: " + vfechaNacimiento + "<br>");
    document.write("Domicilio: " + vdomicilio + "<br>");
    document.write("Localidad: " + vlocalidad + "<br>");
}
