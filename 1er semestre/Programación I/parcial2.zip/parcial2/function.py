import random
#importamos random para prueba de codigo
def verify_letter(letter):
    #verificamos si el usuario ingreso una letra correcta
    if letter== "A" or letter=="T" or letter=="C" or letter=="G":
        return letter
    else:
        #si no la ingreso le pedimos que la cargue nuevamente y volvemos a llamar a la funcion
        print("CARACTER INGRESADO INCORRECTAMENTE")
        letter=input("INGRESE UNA LETRA ENTRE [A],[T],[C],[G] :").upper()
        return verify_letter(letter)
#funciono para sacar adn randow y ir probando el porgrama
# def random_letter():
#     num=random.randint(1,4)
#     # num=1
#     if num==1:
#         letter="A"
#     if num==2:
#         letter="T"
#     if num==3:
#         letter="C"
#     if num==4:
#         letter="G"
#     return letter
# imprimimos la matriz con el adn
def print_adn(adn):

    for row in adn:

        print("-----------------------------------------------")
        for col in row:
            print("[ ",col," ]",end="|")
        print(" ")
        print("------------------------------------------------")

# verificamos los casos donde coincide el adn en la matriz 
def verify_is_mutant(adn):
    #DECLARAMOS VACIO COINCIDENCE PARA QUE ANOTE DONDE HALLAN COINCIDENCIAS
    coincidence=[]
    #DECLARAMOS is_mutant PARA QUE CUENTE LAS COINCIDENCIAS QUE ENCUENTRA
    is_mutant=0
    # VERTICAL
    for row in range(6):
        for col in range(3):
            if adn[row][col]==adn[row][1+col]==adn[row][2+col]==adn[row][3+col]:
                is_mutant+=1
                secuence=adn[row][0]+adn[row][1]+adn[row][2]+adn[row][3]+adn[row][4]+adn[row][5]
                coincidence.append(secuence)
                break
    # HORIZONTAL
    for col in range(6):
        for row in range(3):
            if adn[row][col]==adn[row+1][col]==adn[row+2][col]==adn[row+3][col]:
                is_mutant+=1
                secuence=adn[0][col]+adn[1][col]+adn[2][col]+adn[3][col]+adn[4][col]+adn[5][col]
                coincidence.append(secuence)
                break
    #DIAGONAL
    for row in range(3):
        if row==0:
            for i in range(3):
                #PRINCIPÁL 
                if adn[i][i]== adn[i+1][i+1]== adn[i+2][i+2]==adn[i+3][i+3]:
                    is_mutant+=1
                    secuence=adn[0][0]+ adn[1][1]+ adn[2][2]+adn[3][3]+ adn[4][4]+adn[5][5]
                    coincidence.append(secuence)
                    break
                #INVERSA PRINCIPAL
                if adn[i][5-i]== adn[i+1][4-i]== adn[i+2][3-i]==adn[i+3][2-+i]:
                    is_mutant+=1
                    secuence=adn[0][5]+ adn[1][4]+ adn[2][3]+adn[3][2]+ adn[4][1]+adn[5][0]
                    coincidence.append(secuence)
                    break
        #DIAGONALES SECUNDARIAS 
        elif row==1:
            #DECLARAMOS secondary_secuence PARA CUANDO ENCUENTRE UN ADN QUE COINCIDE NO VOLVERLO A AGREGAR 
            secondary_secuence=[False,False,False,False]
            for i in range(2):
                #SECUNDARIA
                if secondary_secuence[0] is not True:
                    if adn[i+1][i]== adn[i+2][i+1]== adn[i+3][i+2]==adn[i+4][i+3]:
                        is_mutant+=1
                        secuence=adn[1][0]+ adn[2][1]+ adn[3][2]+adn[4][3]+ adn[5][4]
                        coincidence.append(secuence)
                        secondary_secuence[0]=True
                if secondary_secuence[1] is not True:
                    if adn[i][i+1]== adn[i+1][i+2]== adn[i+2][i+3]==adn[i+3][i+4]:
                        is_mutant+=1
                        secuence=adn[0][1]+ adn[1][2]+ adn[2][3]+adn[3][4]+ adn[4][5]
                        coincidence.append(secuence)
                        secondary_secuence[1]=True
                #SECUNDARIA INVERSA
                if secondary_secuence[2] is not True:
                    if adn[i+1][5-i]== adn[i+2][4-i]== adn[i+3][3-i]==adn[i+4][2-i]:
                        is_mutant+=1
                        secuence=adn[1][5]+ adn[2][4]+ adn[3][3]+adn[4][2]+adn[5][1]
                        coincidence.append(secuence)
                        secondary_secuence[2]=True
                if secondary_secuence[3] is not True:
                    if adn[i][4-i]== adn[i+1][3-i]== adn[i+2][i+2]==adn[i+3][i+1]:
                            is_mutant+=1
                            secuence=adn[1][4]+ adn[1][3]+ adn[2][2]+adn[3][1]+adn[4][1+0]
                            coincidence.append(secuence)
                            secondary_secuence[3]=True

                
        else:
            if adn[2][0]== adn[3][1]== adn[4][2]==adn[5][3]:
                is_mutant+=1
                secuence=adn[2][0]+ adn[3][1]+ adn[4][2]+adn[5][3]
                coincidence.append(secuence)
            if adn[0][2]== adn[1][3]== adn[2][4]==adn[3][5]:
                is_mutant+=1
                secuence=adn[0][2]+ adn[1][3]+ adn[2][4]+adn[3][5]
                coincidence.append(secuence)
    #SI ENCONTRO MAS DE UNA COINCIDENCIA DEVUELVE TRUE SI NO DEVUELVE FALSE
    print(f"LAS COINCIDENCIAS SON : {coincidence}")
    if is_mutant>1:
 
        return True
    else:
        
        return False
                