# Te ha contratado a ti para que desarrolles un programa que detecte si un humano es
# mutante basándose en su secuencia de ADN.Para eso te ha pedido crear un programa con un método o función booleana,
# llamada is_mutant(dna),# que recibe como parámetro un arreglo 
# de Strings que # representan cada fila de una matriz 6x6 con la secuencia de ADN.
# Las letras de los Strings solo pueden ser: A,T,C,G;
# las cuales representan cada base nitrogenada del ADN.
# Sabrás si un humano es mutante, si encuentras más de una secuencia de cuatro letras iguales,
# estas pueden aparecer de forma oblicua, horizontal o vertical.



#detectar si un humano es mutante basandose en una secuencia de ADN
#hacer una matriz de 6x6
#solo pueden ser a,t,c,g
#secuencia de 4 letras

#Ingresar secuencia 6x6 ADN
# ir validando si cumple con las letras
#fijarse si es mutante 
#devolver si es mutante o no 
#
from function import *
import random
#DECLARAMOS LA MATRIZ DE 6X6 VACIA
adn=[[None for _ in range(6)]for _ in range(6)]
#RECORREMOS LA MATRIZ
for row in range(6):
    print("------------------------------------------------------------")
    for col in range(6):
        print(f"Fila : {row+1}, Columna: {col+1}")
        letter=input("INGRESE UNA LETRA ENTRE [A],[T],[C],[G] :").upper()
        # verify_letter(letter)
        #funcion Randow para ir probando el programa sin cargar constantemente
        # letter=random_letter()
        adn[row][col]=letter

# ADN DE MUTANTE        
# adn=[ 
#     ["T","T","C","G","G","A"],
#     ["A","T","T","G","A","C"],
#     ["T","A","G","T","C","T"],
#     ["A","T","G","C","T","C"],
#     ["G","T","T","T","A","T"],
#     ["T","C","T","T","A","C"]
# ]
# # ADN DE NO MUTANTE
# adn=[
#     ["T","T","C","G","G","A"],
#     ["A","T","T","G","A","C"],
#     ["T","A","G","T","C","T"],
#     ["A","A","G","C","T","C"],
#     ["G","T","T","T","A","T"],
#     ["T","C","T","T","A","C"]
# ]
print_adn(adn)
is_win=verify_is_mutant(adn)
if is_win is True:
    print("EL ADN PERTENECE A LOS GENES DE UN MUTANTE")
else:
    print("EL ADN NO PERTENECE A LOS GENES DE UNA PERSONA MUTANTE")