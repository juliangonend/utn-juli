# ParcialMutanteLabI
examen sobre veificar si el adn de una persona es mutante o no basandose en una secuencia de adn de una matriz de 6x6

Nombre:Julián Gonzalez Endzweig
comision b
link github : https://github.com/juliangonend/ParcialMutanteLabI.git