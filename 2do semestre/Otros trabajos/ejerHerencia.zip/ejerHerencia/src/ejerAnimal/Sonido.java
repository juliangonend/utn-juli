package ejerAnimal;

public interface Sonido {
    void hacerSonido();
}
