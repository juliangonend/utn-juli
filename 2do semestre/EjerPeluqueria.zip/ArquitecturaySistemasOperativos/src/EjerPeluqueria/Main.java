package EjerPeluqueria;

public class Main {
    public static void main(String[] args) {
        Peluqueria peluqueria = new Peluqueria();
        peluqueria.iniciar();
    }
}
