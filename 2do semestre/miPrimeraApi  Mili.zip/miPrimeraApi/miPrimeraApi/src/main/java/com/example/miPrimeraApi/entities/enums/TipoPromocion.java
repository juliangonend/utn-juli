package com.example.miPrimeraApi.entities.enums;

public enum TipoPromocion {
    HAPPYHOUR,
    PROMOCION
}
