package com.example.miPrimeraApi.repositories;

import com.example.miPrimeraApi.entities.Pais;
import org.springframework.stereotype.Repository;

@Repository
public interface PaisRepository extends BaseRepository<Pais,Long>{
}
