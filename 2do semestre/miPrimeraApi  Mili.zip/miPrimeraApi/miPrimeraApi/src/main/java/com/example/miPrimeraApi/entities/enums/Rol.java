package com.example.miPrimeraApi.entities.enums;

public enum Rol {
    COCINERO,
    CAJERO,
    DELIVERY,
    ADMIN,
    CLIENTE
}
