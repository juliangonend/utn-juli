package com.example.miPrimeraApi.repositories;

import com.example.miPrimeraApi.entities.UnidadMedida;
import org.springframework.stereotype.Repository;

@Repository
public interface UnidadMedidaRepository extends BaseRepository<UnidadMedida,Long> {
}
