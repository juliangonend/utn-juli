package com.example.miPrimeraApi.repositories;

import com.example.miPrimeraApi.entities.Factura;
import org.springframework.stereotype.Repository;

@Repository
public interface FacturaRepository extends BaseRepository<Factura,Long> {
    Factura findAllByPedidoId(Long idPedido);
}
