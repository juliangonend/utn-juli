package com.example.miPrimeraApi.entities.enums;

public enum TipoEnvio {
    DELIVERY,
    TAKEAWAY
}
