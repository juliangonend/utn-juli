package com.example.miPrimeraApi.entities.enums;

public enum Estado {
    PREPARACION,
    PENDIENTE,
    CANCELADO,
    RECHAZADO,
    ENTREGADO
}
