package com.example.miPrimeraApi.entities.enums;

public enum FormaPago {
    EFECTIVO,
    MERCADOPAGO
}
