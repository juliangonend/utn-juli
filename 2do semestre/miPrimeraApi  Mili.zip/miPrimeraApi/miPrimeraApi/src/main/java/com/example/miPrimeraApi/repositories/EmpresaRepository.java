package com.example.miPrimeraApi.repositories;

import com.example.miPrimeraApi.entities.Empresa;
import org.springframework.stereotype.Repository;

@Repository
public interface EmpresaRepository extends BaseRepository<Empresa,Long> {
}
